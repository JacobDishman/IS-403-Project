const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { requireAuth } = require('../middleware/auth');

// All dashboard routes require authentication
router.use(requireAuth);

// Dashboard main page (Goals view)
router.get('/', async (req, res) => {
    try {
        const userId = req.session.user.user_id;

        // Get all goals for the user
        const goalsResult = await pool.query(
            `SELECT * FROM goals
             WHERE user_id = $1
             ORDER BY category, created_at DESC`,
            [userId]
        );

        // Get today's events
        const eventsResult = await pool.query(
            `SELECT * FROM events
             WHERE user_id = $1 AND event_date = CURRENT_DATE
             ORDER BY start_time`,
            [userId]
        );

        // Calculate statistics
        const statsResult = await pool.query(
            `SELECT
                (SELECT COUNT(*)::INTEGER FROM goals WHERE user_id = $1) as total,
                (SELECT COUNT(*)::INTEGER FROM goals WHERE user_id = $1 AND is_completed = TRUE) as completed,
                (SELECT COUNT(*)::INTEGER FROM goals WHERE user_id = $1 AND is_completed = FALSE) as active,
                (SELECT COUNT(*)::INTEGER FROM events WHERE user_id = $1 AND event_date = CURRENT_DATE) as eventstoday`,
            [userId]
        );

        const stats = statsResult.rows[0];

        // Group goals by category (capitalize first letter to match DB)
        const goalsByCategory = {
            'Spiritual': [],
            'Social': [],
            'Intellectual': [],
            'Physical': [],
            'Romantic': []
        };

        goalsResult.rows.forEach(goal => {
            const category = goal.category.charAt(0).toUpperCase() + goal.category.slice(1).toLowerCase();
            if (goalsByCategory[category]) {
                goalsByCategory[category].push(goal);
            }
        });

        // Calculate progress for each category
        const progress = {};
        Object.keys(goalsByCategory).forEach(category => {
            const categoryGoals = goalsByCategory[category];
            if (categoryGoals.length > 0) {
                const completed = categoryGoals.filter(g => g.is_completed).length;
                progress[category.toLowerCase()] = Math.round((completed / categoryGoals.length) * 100);
            } else {
                progress[category.toLowerCase()] = 0;
            }
        });

        res.render('dashboard', {
            pageTitle: 'Goals Dashboard - Cal-Endure to the End',
            currentPage: 'dashboard',
            goals: goalsResult.rows,
            goalsByCategory,
            events: eventsResult.rows,
            stats,
            progress
        });

    } catch (error) {
        console.error('Dashboard error:', error);
        req.session.error = 'Error loading dashboard';
        res.redirect('/');
    }
});

module.exports = router;
