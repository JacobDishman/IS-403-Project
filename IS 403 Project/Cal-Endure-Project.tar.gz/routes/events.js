const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { requireAuth } = require('../middleware/auth');

// All event routes require authentication
router.use(requireAuth);

// Calendar main page
router.get('/', async (req, res) => {
    try {
        const userId = req.session.user.user_id;
        const { year, month } = req.query;

        // Get current date or use provided year/month
        const today = new Date();
        const currentYear = year ? parseInt(year) : today.getFullYear();
        const currentMonth = month ? parseInt(month) : today.getMonth() + 1;

        // Get all events for the current month
        const eventsResult = await pool.query(
            `SELECT e.*,
                    ARRAY_AGG(
                        CASE
                            WHEN c.contact_id IS NOT NULL
                            THEN json_build_object(
                                'contact_id', c.contact_id,
                                'first_name', c.first_name,
                                'last_name', c.last_name
                            )
                        END
                    ) FILTER (WHERE c.contact_id IS NOT NULL) as contacts
             FROM events e
             LEFT JOIN contact_events ce ON e.event_id = ce.event_id
             LEFT JOIN contacts c ON ce.contact_id = c.contact_id
             WHERE e.user_id = $1
               AND EXTRACT(YEAR FROM e.event_date) = $2
               AND EXTRACT(MONTH FROM e.event_date) = $3
             GROUP BY e.event_id
             ORDER BY e.event_date, e.start_time`,
            [userId, currentYear, currentMonth]
        );

        // Get today's events
        const todayEventsResult = await pool.query(
            `SELECT e.*,
                    ARRAY_AGG(
                        CASE
                            WHEN c.contact_id IS NOT NULL
                            THEN json_build_object(
                                'contact_id', c.contact_id,
                                'first_name', c.first_name,
                                'last_name', c.last_name
                            )
                        END
                    ) FILTER (WHERE c.contact_id IS NOT NULL) as contacts
             FROM events e
             LEFT JOIN contact_events ce ON e.event_id = ce.event_id
             LEFT JOIN contacts c ON ce.contact_id = c.contact_id
             WHERE e.user_id = $1 AND e.event_date = CURRENT_DATE
             GROUP BY e.event_id
             ORDER BY e.start_time`,
            [userId]
        );

        // Get all contacts for the contact selector
        const contactsResult = await pool.query(
            'SELECT contact_id, first_name, last_name FROM contacts WHERE user_id = $1 ORDER BY last_name, first_name',
            [userId]
        );

        res.render('calendar', {
            pageTitle: 'Calendar - Cal-Endure to the End',
            currentPage: 'calendar',
            events: eventsResult.rows,
            todayEvents: todayEventsResult.rows,
            contacts: contactsResult.rows,
            currentYear,
            currentMonth,
            today: {
                year: today.getFullYear(),
                month: today.getMonth() + 1,
                day: today.getDate()
            }
        });

    } catch (error) {
        console.error('Calendar error:', error);
        req.session.error = 'Error loading calendar';
        res.redirect('/dashboard');
    }
});

// Create new event
router.post('/create', async (req, res) => {
    const {
        title, eventDate, startTime, endTime, eventType,
        location, notes, contacts
    } = req.body;
    const userId = req.session.user.user_id;

    try {
        // Insert event (removed reminder parameter)
        const eventResult = await pool.query(
            `INSERT INTO events (user_id, title, event_date, start_time, end_time, event_type, location, notes)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
             RETURNING event_id`,
            [userId, title, eventDate, startTime, endTime || null, eventType, location, notes]
        );

        const eventId = eventResult.rows[0].event_id;

        // Associate contacts with event
        if (contacts) {
            const contactIds = Array.isArray(contacts) ? contacts : [contacts];
            for (const contactId of contactIds) {
                if (contactId) { // Check contactId is not empty
                    await pool.query(
                        'INSERT INTO contact_events (contact_id, event_id) VALUES ($1, $2)',
                        [contactId, eventId]
                    );
                }
            }
        }

        req.session.success = 'Event created successfully';
        res.redirect('/calendar');

    } catch (error) {
        console.error('Create event error:', error);
        req.session.error = 'Error creating event: ' + error.message;
        res.redirect('/calendar');
    }
});

// Get single event (for editing)
router.get('/:id', async (req, res) => {
    const { id } = req.params;
    const userId = req.session.user.user_id;

    try {
        const eventResult = await pool.query(
            `SELECT e.*,
                    ARRAY_AGG(ce.contact_id) FILTER (WHERE ce.contact_id IS NOT NULL) as contact_ids
             FROM events e
             LEFT JOIN contact_events ce ON e.event_id = ce.event_id
             WHERE e.event_id = $1 AND e.user_id = $2
             GROUP BY e.event_id`,
            [id, userId]
        );

        if (eventResult.rows.length === 0) {
            return res.status(404).json({ error: 'Event not found' });
        }

        res.json({ event: eventResult.rows[0] });

    } catch (error) {
        console.error('Get event error:', error);
        res.status(500).json({ error: 'Error loading event' });
    }
});

// Update event
router.post('/update/:id', async (req, res) => {
    const { id } = req.params;
    const {
        title, eventDate, startTime, endTime, eventType,
        location, notes, reminder, contacts
    } = req.body;
    const userId = req.session.user.user_id;

    try {
        // Update event
        await pool.query(
            `UPDATE events
             SET title = $1, event_date = $2, start_time = $3, end_time = $4,
                 event_type = $5, location = $6, notes = $7, reminder = $8
             WHERE event_id = $9 AND user_id = $10`,
            [title, eventDate, startTime, endTime || null, eventType, location, notes,
             reminder === 'on', id, userId]
        );

        // Delete existing contact associations
        await pool.query('DELETE FROM contact_events WHERE event_id = $1', [id]);

        // Add new contact associations
        if (contacts) {
            const contactIds = Array.isArray(contacts) ? contacts : [contacts];
            for (const contactId of contactIds) {
                await pool.query(
                    'INSERT INTO contact_events (contact_id, event_id) VALUES ($1, $2)',
                    [contactId, id]
                );
            }
        }

        req.session.success = 'Event updated successfully';
        res.redirect('/calendar');

    } catch (error) {
        console.error('Update event error:', error);
        req.session.error = 'Error updating event';
        res.redirect('/calendar');
    }
});

// Delete event
router.post('/delete/:id', async (req, res) => {
    const { id } = req.params;
    const userId = req.session.user.user_id;

    try {
        await pool.query(
            'DELETE FROM events WHERE event_id = $1 AND user_id = $2',
            [id, userId]
        );

        req.session.success = 'Event deleted successfully';
        res.redirect('/calendar');

    } catch (error) {
        console.error('Delete event error:', error);
        req.session.error = 'Error deleting event';
        res.redirect('/calendar');
    }
});

// Update event date (for drag-and-drop)
router.post('/move/:id', async (req, res) => {
    const { id } = req.params;
    const { newDate } = req.body;
    const userId = req.session.user.user_id;

    try {
        await pool.query(
            'UPDATE events SET event_date = $1 WHERE event_id = $2 AND user_id = $3',
            [newDate, id, userId]
        );

        res.json({ success: true });

    } catch (error) {
        console.error('Move event error:', error);
        res.status(500).json({ success: false, error: 'Error moving event' });
    }
});

module.exports = router;
