const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { requireAuth } = require('../middleware/auth');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, '../uploads/contacts');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'contact-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: (req, file, cb) => {
        const allowedTypes = /jpeg|jpg|png|gif/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);

        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only image files are allowed'));
        }
    }
});

// All contact routes require authentication
router.use(requireAuth);

// Contacts list page
router.get('/', async (req, res) => {
    try {
        const userId = req.session.user.user_id;
        const { search, filter } = req.query;

        let query = `
            SELECT c.*,
                   COUNT(DISTINCT ce.event_id) as event_count
            FROM contacts c
            LEFT JOIN contact_events ce ON c.contact_id = ce.contact_id
            WHERE c.user_id = $1
        `;
        const params = [userId];

        // Add search filter
        if (search) {
            query += ` AND (
                LOWER(c.first_name || ' ' || c.last_name) LIKE LOWER($2)
                OR LOWER(c.email) LIKE LOWER($2)
                OR LOWER(c.phone) LIKE LOWER($2)
            )`;
            params.push(`%${search}%`);
        }

        query += ' GROUP BY c.contact_id ORDER BY c.last_name, c.first_name';

        const result = await pool.query(query, params);
        let contacts = result.rows;

        // Apply favorite filter
        if (filter === 'favorites') {
            contacts = contacts.filter(c => c.is_favorite);
        } else if (filter === 'recent') {
            contacts = contacts.slice(0, 10);
        }

        res.render('contacts', {
            pageTitle: 'Contacts - Cal-Endure to the End',
            currentPage: 'contacts',
            contacts,
            search: search || '',
            filter: filter || 'all'
        });

    } catch (error) {
        console.error('Contacts list error:', error);
        req.session.error = 'Error loading contacts';
        res.redirect('/dashboard');
    }
});

// Create new contact
router.post('/create', upload.single('photo'), async (req, res) => {
    const {
        firstName, lastName, phone, email,
        streetAddress, city, state, zipCode, notes
    } = req.body;
    const userId = req.session.user.user_id;

    try {
        const photo = req.file ? `/uploads/contacts/${req.file.filename}` : 'https://via.placeholder.com/150';

        await pool.query(
            `INSERT INTO contacts (user_id, first_name, last_name, phone, email,
                                  street_address, city, state, zip_code, photo, notes)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
            [userId, firstName, lastName, phone, email, streetAddress, city, state, zipCode, photo, notes]
        );

        req.session.success = 'Contact created successfully';
        res.redirect('/contacts');

    } catch (error) {
        console.error('Create contact error:', error);
        req.session.error = 'Error creating contact';
        res.redirect('/contacts');
    }
});

// Get single contact (for editing)
router.get('/:id', async (req, res) => {
    const { id } = req.params;
    const userId = req.session.user.user_id;

    try {
        const contactResult = await pool.query(
            'SELECT * FROM contacts WHERE contact_id = $1 AND user_id = $2',
            [id, userId]
        );

        if (contactResult.rows.length === 0) {
            req.session.error = 'Contact not found';
            return res.redirect('/contacts');
        }

        const eventsResult = await pool.query(
            `SELECT e.* FROM events e
             JOIN contact_events ce ON e.event_id = ce.event_id
             WHERE ce.contact_id = $1 AND e.user_id = $2
             ORDER BY e.event_date DESC, e.start_time DESC`,
            [id, userId]
        );

        res.json({
            contact: contactResult.rows[0],
            events: eventsResult.rows
        });

    } catch (error) {
        console.error('Get contact error:', error);
        res.status(500).json({ error: 'Error loading contact' });
    }
});

// Update contact
router.post('/update/:id', upload.single('photo'), async (req, res) => {
    const { id } = req.params;
    const {
        firstName, lastName, phone, email,
        streetAddress, city, state, zipCode, notes
    } = req.body;
    const userId = req.session.user.user_id;

    try {
        // Get current contact to check if photo exists
        const currentContact = await pool.query(
            'SELECT photo FROM contacts WHERE contact_id = $1 AND user_id = $2',
            [id, userId]
        );

        if (currentContact.rows.length === 0) {
            req.session.error = 'Contact not found';
            return res.redirect('/contacts');
        }

        let photo = currentContact.rows[0].photo;

        // If new photo uploaded, use it
        if (req.file) {
            photo = `/uploads/contacts/${req.file.filename}`;

            // Delete old photo if it's not a placeholder
            const oldPhoto = currentContact.rows[0].photo;
            if (oldPhoto && !oldPhoto.includes('placeholder') && !oldPhoto.includes('via.placeholder')) {
                const oldPhotoPath = path.join(__dirname, '..', oldPhoto);
                if (fs.existsSync(oldPhotoPath)) {
                    fs.unlinkSync(oldPhotoPath);
                }
            }
        }

        await pool.query(
            `UPDATE contacts
             SET first_name = $1, last_name = $2, phone = $3, email = $4,
                 street_address = $5, city = $6, state = $7, zip_code = $8,
                 photo = $9, notes = $10
             WHERE contact_id = $11 AND user_id = $12`,
            [firstName, lastName, phone, email, streetAddress, city, state, zipCode,
             photo, notes, id, userId]
        );

        req.session.success = 'Contact updated successfully';
        res.redirect('/contacts');

    } catch (error) {
        console.error('Update contact error:', error);
        req.session.error = 'Error updating contact';
        res.redirect('/contacts');
    }
});

// Toggle favorite
router.post('/favorite/:id', async (req, res) => {
    const { id } = req.params;
    const userId = req.session.user.user_id;

    try {
        await pool.query(
            `UPDATE contacts
             SET is_favorite = NOT is_favorite
             WHERE contact_id = $1 AND user_id = $2`,
            [id, userId]
        );

        res.json({ success: true });

    } catch (error) {
        console.error('Toggle favorite error:', error);
        res.status(500).json({ success: false, error: 'Error updating favorite status' });
    }
});

// Delete contact
router.post('/delete/:id', async (req, res) => {
    const { id } = req.params;
    const userId = req.session.user.user_id;

    try {
        // Get contact to find photo
        const result = await pool.query(
            'SELECT photo FROM contacts WHERE contact_id = $1 AND user_id = $2',
            [id, userId]
        );

        if (result.rows.length === 0) {
            req.session.error = 'Contact not found';
            return res.redirect('/contacts');
        }

        const photo = result.rows[0].photo;

        // Delete contact (cascade will delete contact_events)
        await pool.query(
            'DELETE FROM contacts WHERE contact_id = $1 AND user_id = $2',
            [id, userId]
        );

        // Delete photo file if it's not a placeholder
        if (photo && !photo.includes('placeholder') && !photo.includes('via.placeholder')) {
            const photoPath = path.join(__dirname, '..', photo);
            if (fs.existsSync(photoPath)) {
                fs.unlinkSync(photoPath);
            }
        }

        req.session.success = 'Contact deleted successfully';
        res.redirect('/contacts');

    } catch (error) {
        console.error('Delete contact error:', error);
        req.session.error = 'Error deleting contact';
        res.redirect('/contacts');
    }
});

module.exports = router;
