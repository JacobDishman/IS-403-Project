const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const pool = require('../config/database');
const { requireGuest } = require('../middleware/auth');

// Landing page
router.get('/', (req, res) => {
    res.render('landing', {
        pageTitle: 'Cal-Endure to the End - PMG Calendar for Returned Missionaries'
    });
});

// Login page
router.get('/login', requireGuest, (req, res) => {
    res.render('login', {
        pageTitle: 'Login - Cal-Endure to the End'
    });
});

// Handle login
router.post('/login', requireGuest, async (req, res) => {
    const { email, password, remember } = req.body;

    try {
        // Find user by email
        const result = await pool.query(
            'SELECT * FROM users WHERE email = $1',
            [email]
        );

        if (result.rows.length === 0) {
            req.session.error = 'Invalid email or password';
            return res.redirect('/login');
        }

        const user = result.rows[0];

        // Compare password
        const match = await bcrypt.compare(password, user.password_hash);

        if (!match) {
            req.session.error = 'Invalid email or password';
            return res.redirect('/login');
        }

        // Set session
        req.session.user = {
            user_id: user.user_id,
            first_name: user.first_name,
            last_name: user.last_name,
            email: user.email,
            username: user.username,
            mission: user.mission,
            profile_photo: user.profile_photo
        };

        // Extend session if "remember me" is checked
        if (remember === 'on') {
            req.session.cookie.maxAge = 1000 * 60 * 60 * 24 * 30; // 30 days
        }

        req.session.success = 'Welcome back!';
        res.redirect('/dashboard');

    } catch (error) {
        console.error('Login error:', error);
        req.session.error = 'An error occurred during login';
        res.redirect('/login');
    }
});

// Handle signup
router.post('/signup', requireGuest, async (req, res) => {
    const { firstName, lastName, email, username, password, confirmPassword, mission } = req.body;

    try {
        // Validation
        if (!firstName || !lastName || !email || !username || !password) {
            req.session.error = 'All required fields must be filled';
            return res.redirect('/login#signup');
        }

        if (password !== confirmPassword) {
            req.session.error = 'Passwords do not match';
            return res.redirect('/login#signup');
        }

        if (password.length < 6) {
            req.session.error = 'Password must be at least 6 characters';
            return res.redirect('/login#signup');
        }

        // Check if email or username already exists
        const checkUser = await pool.query(
            'SELECT * FROM users WHERE email = $1 OR username = $2',
            [email, username]
        );

        if (checkUser.rows.length > 0) {
            req.session.error = 'Email or username already exists';
            return res.redirect('/login#signup');
        }

        // Hash password
        const saltRounds = 10;
        const password_hash = await bcrypt.hash(password, saltRounds);

        // Insert new user
        const result = await pool.query(
            `INSERT INTO users (first_name, last_name, email, username, password_hash, mission)
             VALUES ($1, $2, $3, $4, $5, $6)
             RETURNING user_id, first_name, last_name, email, username, mission, profile_photo`,
            [firstName, lastName, email, username, password_hash, mission || null]
        );

        const newUser = result.rows[0];

        // Set session
        req.session.user = {
            user_id: newUser.user_id,
            first_name: newUser.first_name,
            last_name: newUser.last_name,
            email: newUser.email,
            username: newUser.username,
            mission: newUser.mission,
            profile_photo: newUser.profile_photo
        };

        req.session.success = 'Account created successfully! Welcome!';
        res.redirect('/dashboard');

    } catch (error) {
        console.error('Signup error:', error);
        req.session.error = 'An error occurred during signup';
        res.redirect('/login#signup');
    }
});

// Logout
router.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
        }
        res.redirect('/');
    });
});

module.exports = router;
